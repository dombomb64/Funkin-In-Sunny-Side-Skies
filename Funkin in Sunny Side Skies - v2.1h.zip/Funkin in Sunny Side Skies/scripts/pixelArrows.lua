-- NOTE:
-- Feel free to use this script in your mods!
-- Just make sure to give credit to me, dombomb64.
-- (You can delete all the commented-out code, most of it was me messing around.)


function onCreatePost(elapsed)
	--setPropertyFromGroup('notes', 0, 'scale.x', 2);
	--setPropertyFromGroup('notes', 0, 'antialiasing', false);
	--local i = 0;
	--for i = 0, 3, 1 do
		--setPropertyFromGroup('opponentStrums', i, 'antialiasing', false);
		--setPropertyFromGroup('playerStrums', i, 'antialiasing', false);
	--end
	--setProperty('songSpeed', (curBeat % 2) + 1);
end

local curStep = 0; 
--function onStepHit()
	--setProperty('songSpeed', (curStep % 2 * 0.025) + 1);
	--curStep = curStep + 1;
	--debugPrint(curStep);
--end